import React from "react";
import { useDispatch } from "react-redux";
import { decrement, increment } from "../redux/reducernaction/counterSlice";
 

function CounterAction() {
  const dispatch = useDispatch();
  return (
    <div>
      <button onClick={() => dispatch(increment())}>increment</button>
      <button onClick={() => dispatch(decrement())}>decrement</button>
    </div>
  );
}

export default CounterAction;
