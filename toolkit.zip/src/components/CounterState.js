import React from "react";
import { useSelector } from "react-redux";

function CounterState(props) {
  const counterData = useSelector((state) => state.ctr.counter);

  return (
    <div>
      <p>the current state of counter is : {counterData}</p>
    </div>
  );
}

export default CounterState;
