

import React from 'react';
import CounterState from './CounterState';
import CounterAction from './CounterAction';
 
function CounterMain(props) {
    
    return (
        <div>
           <CounterState/>
           <CounterAction/>
        </div>
    );
}

export default CounterMain;