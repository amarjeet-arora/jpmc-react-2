
import {configureStore} from '@reduxjs/toolkit'
import counterReducer from './reducernaction/counterSlice'


export default configureStore({
    reducer:{
        ctr: counterReducer
    }
})