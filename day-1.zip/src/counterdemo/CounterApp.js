import { Component } from "react";

export default class CounterApp extends Component {
  // initialize the state
  state = {
    counter: 0
  };
  // update state

  increment = () => {
    this.setState((prevState) => {
      return {
        counter: prevState.counter + 1,
      };
    });
  };
  render() {
    return (
      <div>
        <p>The counter is : {this.state.counter}</p>
        <button onClick={this.increment}>+</button>
      </div>
    );
  }
}
