import { Component } from "react";
import Footer from "./Footer";
import Header from "./Header";
import User from "./User";

export default class Users extends Component {
  render() {
    return (
      <div>
        {this.props.udata.map((data) => (
          <User key={data} ud={data} 
          deleteOne={this.props.don}
          />
        ))}
        <button
        disabled={!this.props.hasData}
        onClick={this.props.da}>Delete All</button>
      </div>
    );
  }
}
