import { Component } from "react";
import AddUser from "./AddUser";
import Footer from "./Footer";
import Header from "./Header";
import Users from "./Users";

export default class MainApp extends Component {
  state = {
    hdata: "welcome to header",
    userData: [],
  };
  addUser = (data) => {
    this.setState((prevState) => {
      return {
        userData: prevState.userData.concat(data),
      };
    });
  };
  deleteAll=()=>{
    this.setState(()=>{
      return{
        userData:[]
      }
    })
  }
  deleteOne=(data)=>{
    this.setState((prevState)=> ({
      userData:prevState.userData.filter((option) => data !== option)
    }))
  }
  render() {
    return (
      <div>
        <Header headerData={this.state.hdata} />
        <p>welcome to mainapp</p>
        <Users udata={this.state.userData}
         da={this.deleteAll}
         hasData={this.state.userData.length > 0}
         don={this.deleteOne}
        />
        <AddUser au={this.addUser} />
        <Footer />
      </div>
    );
  }
}
