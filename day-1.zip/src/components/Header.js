
import { Component } from 'react'

export default class Header extends Component{

    render(){
        return(
            //JSX (javaascript syntax extensions)
            <div>
                <p>{this.props.headerData}</p>
            </div>
        )
    }
}