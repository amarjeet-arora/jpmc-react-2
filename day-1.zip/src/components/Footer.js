
import { Component } from 'react'

export default class Footer extends Component{

    render(){
        return(
            //JSX (javaascript syntax extensions)
            <div>
                <p>welcome to Footer</p>
            </div>
        )
    }
}