import logo from './logo.svg';
import './App.css';
import MainApp from './components/MainApp';
import CounterApp from './counterdemo/CounterApp';

function App() {
  return (
    <div className="App">
     welcome
     <MainApp/>
     
    </div>
  );
}

export default App;
