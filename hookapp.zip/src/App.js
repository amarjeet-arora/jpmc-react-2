import logo from './logo.svg';
import './App.css';
import HookApp from './hooksdemo/HookApp';
import NoteApp from './hooksdemo/NoteApp';

function App() {
  return (
    <div className="App">
      <NoteApp/>
    </div>
  );
}

export default App;
