import { useState } from "react";
const NoteApp = () => {
  const [users,setUsers] = useState([]);
  const [title,setTitle]= useState('')
  const [email,setEmail]=useState('')

  const addUser=(e)=>{
    e.preventDefault();
      setUsers([
        ...users,{title,email}
      ])
      setTitle('')
      setEmail('')
  }
const deleteUser=(title)=>{
setUsers(users.filter((note)=> note.title !== title))
  }
  return (
    <div>
      {users.map((data) => (
        <div>
          <p>{data.title}</p>
          <p>{data.email}</p>
          <button onClick={()=> deleteUser(data.title)}>delete</button>
        </div>
      ))}
      <form>
      UserName:<input type='text' value={title} onChange={(e)=> setTitle(e.target.value)}/>
      Email:<input type='text' value={email} onChange={(e)=> setEmail(e.target.value)}/>
      <button onClick={addUser}>Add User</button>
      </form>
    </div>
  );
};
export default NoteApp;
