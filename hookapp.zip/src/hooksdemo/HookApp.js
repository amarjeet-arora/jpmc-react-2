import { useEffect, useState } from "react";
const HookApp = () => {
  const [counter, setCount] = useState(0);
  // mix of compdidmount+ and didupdate
  useEffect(()=>{
    console.log('called on load');
  },[])
  useEffect(()=>{
    console.log('called on state change');
  },[counter])
  return (
    <div>
      <p>The counter is : {counter}</p>
      <button onClick={() => setCount(counter + 1)}>increment</button>
    </div>
  );
};
export default HookApp;
