import React from 'react';

function ProductDetails(props) {
    return(
        <div className='ui grid container'>
        <h1>Product details component</h1>
     </div>
        )
}

export default ProductDetails;