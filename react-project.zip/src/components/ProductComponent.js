import React from "react";
import { useSelector, useDispatch } from "react-redux";

function ProductComponent(props) {
  const productData = useSelector((state) => state.allProducts.products);
  const renderList = productData.map((product) => {
    const { id, title, image, price, category } = product;
    return (
      <div className="four wide column">
        <div className="ui link cards">
          <div className="card">
            <div className="image">
              <img src={image} />
            </div>
            <div className="content">
              <div className="header">{title}</div>
              <div className="meta price">${price}</div>
              <div className="meta">{category}</div>
            </div>
          </div>
        </div>
      </div>
    );
  });

  return <>
  {renderList}
  </>;
}

export default ProductComponent;
