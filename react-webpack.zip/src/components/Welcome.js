
import React ,{Component} from "react";


export default class Welcome extends Component{

    render(){
        return(
            <div>
                <p>welcome to react</p>
            </div>
        )
    }
}