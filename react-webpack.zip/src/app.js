import React from "react";
import  ReactDOM  from "react-dom";
import Welcome from "./components/Welcome";


ReactDOM.render(<Welcome/>,document.getElementById('show'))